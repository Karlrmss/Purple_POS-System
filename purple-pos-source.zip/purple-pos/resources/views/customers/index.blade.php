@extends('layouts.app')

@section('title', 'Customers')
@section('eyebrow', 'Directory')
@section('page-title', 'Customer records')

@section('content')
    <section class="list-intro">
        <div>
            <span class="section-kicker">CUSTOMER DATABASE</span>
            <h2>Customers</h2>
            <p>View contact information stored in the database.</p>
        </div>
    </section>

    <section class="panel table-panel">
        <div class="table-toolbar">
            <div><p class="eyebrow">All records</p><h3>Customers</h3></div>
            <form class="search" action="{{ route('customers.index') }}" method="GET">
                <svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="m20 20-4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                <label class="sr-only" for="customer-search">Search customers</label>
                <input id="customer-search" name="search" value="{{ $search }}" placeholder="Search name, email, phone…">
                @if($search)<a href="{{ route('customers.index') }}" aria-label="Clear search">×</a>@endif
            </form>
        </div>

        <div class="table-scroll">
            <table>
                <thead><tr><th>Customer</th><th>Email address</th><th>Phone number</th><th>Status</th></tr></thead>
                <tbody>
                    @forelse($customers as $customer)
                        <tr>
                            <td><div class="person-cell"><span class="avatar avatar-customer">{{ collect(explode(' ', $customer->full_name))->map(fn ($name) => $name[0])->take(2)->join('') }}</span><div><strong>{{ $customer->full_name }}</strong><small>#{{ str_pad($customer->id, 4, '0', STR_PAD_LEFT) }}</small></div></div></td>
                            <td><a class="email-link" href="mailto:{{ $customer->email }}">{{ $customer->email }}</a></td>
                            <td>{{ $customer->phone }}</td>
                            <td><span class="active-pill"><i></i> Active</span></td>
                        </tr>
                    @empty
                        <tr><td colspan="4"><div class="empty-state">No customers match “{{ $search }}”. Try a different search.</div></td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="table-footer"><span>Showing {{ $customers->count() }} database {{ Str::plural('record', $customers->count()) }}</span><span>Source: <code>Customer::query()</code></span></div>
    </section>
@endsection
