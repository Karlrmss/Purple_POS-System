@extends('layouts.app')

@section('title', 'System Users')
@section('eyebrow', 'Access directory')
@section('page-title', 'System users')

@section('content')
    <section class="list-intro users-intro">
        <div>
            <span class="section-kicker">TEAM DIRECTORY</span>
            <h2>System users</h2>
            <p>View user accounts stored in the database.</p>
        </div>
    </section>

    <section class="panel table-panel">
        <div class="table-toolbar">
            <div><p class="eyebrow">Authorized team</p><h3>User accounts</h3></div>
            <form class="search" action="{{ route('users.index') }}" method="GET">
                <svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="m20 20-4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                <label class="sr-only" for="user-search">Search system users</label>
                <input id="user-search" name="search" value="{{ $search }}" placeholder="Search name or username…">
                @if($search)<a href="{{ route('users.index') }}" aria-label="Clear search">×</a>@endif
            </form>
        </div>

        <div class="user-grid">
            @forelse($users as $index => $user)
                <article class="user-card">
                    <div class="user-card-top">
                        <span class="avatar avatar-user avatar-tone-{{ ($index % 4) + 1 }}">{{ collect(explode(' ', $user->full_name))->map(fn ($name) => $name[0])->take(2)->join('') }}</span>
                        <span class="active-pill"><i></i> Active</span>
                    </div>
                    <h3>{{ $user->full_name }}</h3>
                    <p>&#64;{{ $user->username }}</p>
                    <div class="user-meta"><span>USER ID</span><strong>#{{ str_pad($user->id, 3, '0', STR_PAD_LEFT) }}</strong></div>
                </article>
            @empty
                <div class="empty-state grid-empty">No users match “{{ $search }}”. Try a different search.</div>
            @endforelse
        </div>
        <div class="table-footer"><span>Showing {{ $users->count() }} database {{ Str::plural('record', $users->count()) }}</span><span>Source: <code>User::query()</code></span></div>
    </section>
@endsection
