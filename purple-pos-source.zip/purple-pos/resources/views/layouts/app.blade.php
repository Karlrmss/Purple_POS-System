<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="PurplePoint database records dashboard">
    <title>@yield('title', 'Dashboard') · PurplePoint</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <div class="app-shell">
        <aside class="sidebar">
            <a class="brand" href="{{ route('dashboard') }}" aria-label="PurplePoint dashboard">
                <span class="brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 28 28" fill="none"><path d="M7 6.5h7.5a6 6 0 1 1 0 12H11v4H7v-16Z" stroke="currentColor" stroke-width="3.2" stroke-linejoin="round"/><circle cx="15" cy="12.5" r="2" fill="currentColor"/></svg>
                </span>
                <span>purple<span>point</span></span>
            </a>

            <nav class="nav-list" aria-label="Main navigation">
                <p class="nav-label">Workspace</p>
                <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
                    <svg viewBox="0 0 24 24" fill="none"><path d="M4 13h6V4H4v9Zm0 7h6v-4H4v4Zm10 0h6v-9h-6v9Zm0-16v4h6V4h-6Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>
                    Overview
                </a>
                <a class="nav-link {{ request()->routeIs('customers.*') ? 'active' : '' }}" href="{{ route('customers.index') }}">
                    <svg viewBox="0 0 24 24" fill="none"><path d="M16 20v-1.7A4.3 4.3 0 0 0 11.7 14H7.3A4.3 4.3 0 0 0 3 18.3V20M9.5 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm8.2 1.7a4 4 0 0 1 3.3 3.94V20m-5.3-17.8a4 4 0 0 1 0 7.75" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                    Customers
                </a>
                <a class="nav-link {{ request()->routeIs('users.*') ? 'active' : '' }}" href="{{ route('users.index') }}">
                    <svg viewBox="0 0 24 24" fill="none"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                    System users
                </a>
            </nav>

        </aside>

        <main class="main-content">
            <header class="topbar">
                <div>
                    <p class="eyebrow">@yield('eyebrow', 'Point of sale')</p>
                    <h1>@yield('page-title', 'Overview')</h1>
                </div>
                <div class="topbar-meta">
                    <span class="date-chip">
                        <svg viewBox="0 0 24 24" fill="none"><path d="M7 3v3m10-3v3M4 9h16M5 5h14a1 1 0 0 1 1 1v14H4V6a1 1 0 0 1 1-1Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
                        {{ now()->format('M d, Y') }}
                    </span>
                </div>
            </header>

            <div class="content-wrap">
                @yield('content')
            </div>

            <footer class="page-footer">
                <span>© {{ now()->year }} PurplePoint</span>
                <span>Built by Karl Ramos · Laravel + Eloquent</span>
            </footer>
        </main>
    </div>
</body>
</html>
