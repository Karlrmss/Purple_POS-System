# PurplePoint POS Records

A purple, database-backed Laravel application created for the laboratory exercise on migrations, seeders, Eloquent models, controllers, and Blade views.

## Features

- Purple responsive dashboard with live database totals
- Customer directory with name, email, and phone details
- System user directory with unique usernames
- Search for customers and users
- Eloquent-only record retrieval (no static arrays or raw SQL)
- Realistic sample data from reusable seeders
- Automated feature tests for all three pages

## Requirements

- PHP 8.3 or newer
- Composer 2
- SQLite extension for PHP (default) or a MySQL database

## Local setup

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd purple-pos
composer install
cp .env.example .env
php artisan key:generate
touch database/database.sqlite
php artisan migrate:fresh --seed
php artisan serve
```

Open [http://127.0.0.1:8000](http://127.0.0.1:8000) in a browser.

For an existing clone that already has a configured `.env`, run only:

```bash
composer install
php artisan migrate:fresh --seed
php artisan serve
```

## Database schema

### `customers`

| Column | Type | Rules |
| --- | --- | --- |
| `id` | integer | Primary key |
| `full_name` | string | Required |
| `email` | string | Required, unique |
| `phone` | string | Required |
| `created_at`, `updated_at` | timestamp | Laravel timestamps |

### `users`

| Column | Type | Rules |
| --- | --- | --- |
| `id` | integer | Primary key |
| `username` | string | Required, unique |
| `full_name` | string | Required |
| `created_at`, `updated_at` | timestamp | Laravel timestamps |

## Important files

- `database/migrations/0001_01_01_000000_create_users_table.php`
- `database/migrations/2026_10_28_000000_create_customers_table.php`
- `database/seeders/CustomerSeeder.php`
- `database/seeders/UserSeeder.php`
- `app/Models/Customer.php`
- `app/Models/User.php`
- `app/Http/Controllers/CustomerController.php`
- `app/Http/Controllers/UserController.php`
- `resources/views/customers/index.blade.php`
- `resources/views/users/index.blade.php`

## Tests

```bash
php artisan test
```

## Hosting notes

Set the web root to the project's `public` directory, configure the production `.env`, then run:

```bash
php artisan migrate --seed --force
php artisan optimize
```

Never commit `.env` or production credentials. After deployment, replace `YOUR_GITHUB_REPOSITORY_URL` above and add the live application link here for submission.

## Author

Made by Karl Ramos.
