<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $users = [
            ['username' => 'karl.admin', 'full_name' => 'Karl Ramos'],
            ['username' => 'bea.cashier', 'full_name' => 'Beatriz Aquino'],
            ['username' => 'nico.staff', 'full_name' => 'Nicolas Villanueva'],
            ['username' => 'ria.manager', 'full_name' => 'Maria Isabel Torres'],
            ['username' => 'sam.inventory', 'full_name' => 'Samuel Dela Cruz'],
            ['username' => 'lea.support', 'full_name' => 'Leah Navarro'],
        ];

        foreach ($users as $user) {
            User::updateOrCreate(['username' => $user['username']], $user);
        }
    }
}
