<?php

namespace Database\Seeders;

use App\Models\Customer;
use Illuminate\Database\Seeder;

class CustomerSeeder extends Seeder
{
    public function run(): void
    {
        $customers = [
            ['full_name' => 'Mikaela Santos', 'email' => 'mikaela.santos@example.com', 'phone' => '+63 917 824 1102'],
            ['full_name' => 'Paolo Reyes', 'email' => 'paolo.reyes@example.com', 'phone' => '+63 998 510 3487'],
            ['full_name' => 'Angela Cruz', 'email' => 'angela.cruz@example.com', 'phone' => '+63 905 774 2091'],
            ['full_name' => 'Joaquin Lim', 'email' => 'joaquin.lim@example.com', 'phone' => '+63 917 316 8840'],
            ['full_name' => 'Sofia Mendoza', 'email' => 'sofia.mendoza@example.com', 'phone' => '+63 926 642 7315'],
            ['full_name' => 'Daniel Garcia', 'email' => 'daniel.garcia@example.com', 'phone' => '+63 939 208 4526'],
        ];

        foreach ($customers as $customer) {
            Customer::updateOrCreate(['email' => $customer['email']], $customer);
        }
    }
}
