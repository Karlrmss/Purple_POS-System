<?php $__env->startSection('title', 'Customers'); ?>
<?php $__env->startSection('eyebrow', 'Directory'); ?>
<?php $__env->startSection('page-title', 'Customer records'); ?>

<?php $__env->startSection('content'); ?>
    <section class="list-intro">
        <div>
            <span class="section-kicker">CUSTOMER DATABASE</span>
            <h2>Customers</h2>
            <p>View contact information stored in the database.</p>
        </div>
    </section>

    <section class="panel table-panel">
        <div class="table-toolbar">
            <div><p class="eyebrow">All records</p><h3>Customers</h3></div>
            <form class="search" action="<?php echo e(route('customers.index')); ?>" method="GET">
                <svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="m20 20-4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                <label class="sr-only" for="customer-search">Search customers</label>
                <input id="customer-search" name="search" value="<?php echo e($search); ?>" placeholder="Search name, email, phone…">
                <?php if($search): ?><a href="<?php echo e(route('customers.index')); ?>" aria-label="Clear search">×</a><?php endif; ?>
            </form>
        </div>

        <div class="table-scroll">
            <table>
                <thead><tr><th>Customer</th><th>Email address</th><th>Phone number</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><div class="person-cell"><span class="avatar avatar-customer"><?php echo e(collect(explode(' ', $customer->full_name))->map(fn ($name) => $name[0])->take(2)->join('')); ?></span><div><strong><?php echo e($customer->full_name); ?></strong><small>#<?php echo e(str_pad($customer->id, 4, '0', STR_PAD_LEFT)); ?></small></div></div></td>
                            <td><a class="email-link" href="mailto:<?php echo e($customer->email); ?>"><?php echo e($customer->email); ?></a></td>
                            <td><?php echo e($customer->phone); ?></td>
                            <td><span class="active-pill"><i></i> Active</span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4"><div class="empty-state">No customers match “<?php echo e($search); ?>”. Try a different search.</div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-footer"><span>Showing <?php echo e($customers->count()); ?> database <?php echo e(Str::plural('record', $customers->count())); ?></span><span>Source: <code>Customer::query()</code></span></div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karlramos/Documents/Codex/2026-10-28/program-outcome-s-po-addressed-by/outputs/purple-pos/resources/views/customers/index.blade.php ENDPATH**/ ?>