<?php $__env->startSection('title', 'System Users'); ?>
<?php $__env->startSection('eyebrow', 'Access directory'); ?>
<?php $__env->startSection('page-title', 'System users'); ?>

<?php $__env->startSection('content'); ?>
    <section class="list-intro users-intro">
        <div>
            <span class="section-kicker">TEAM DIRECTORY</span>
            <h2>System users</h2>
            <p>View user accounts stored in the database.</p>
        </div>
    </section>

    <section class="panel table-panel">
        <div class="table-toolbar">
            <div><p class="eyebrow">Authorized team</p><h3>User accounts</h3></div>
            <form class="search" action="<?php echo e(route('users.index')); ?>" method="GET">
                <svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="m20 20-4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                <label class="sr-only" for="user-search">Search system users</label>
                <input id="user-search" name="search" value="<?php echo e($search); ?>" placeholder="Search name or username…">
                <?php if($search): ?><a href="<?php echo e(route('users.index')); ?>" aria-label="Clear search">×</a><?php endif; ?>
            </form>
        </div>

        <div class="user-grid">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="user-card">
                    <div class="user-card-top">
                        <span class="avatar avatar-user avatar-tone-<?php echo e(($index % 4) + 1); ?>"><?php echo e(collect(explode(' ', $user->full_name))->map(fn ($name) => $name[0])->take(2)->join('')); ?></span>
                        <span class="active-pill"><i></i> Active</span>
                    </div>
                    <h3><?php echo e($user->full_name); ?></h3>
                    <p>&#64;<?php echo e($user->username); ?></p>
                    <div class="user-meta"><span>USER ID</span><strong>#<?php echo e(str_pad($user->id, 3, '0', STR_PAD_LEFT)); ?></strong></div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state grid-empty">No users match “<?php echo e($search); ?>”. Try a different search.</div>
            <?php endif; ?>
        </div>
        <div class="table-footer"><span>Showing <?php echo e($users->count()); ?> database <?php echo e(Str::plural('record', $users->count())); ?></span><span>Source: <code>User::query()</code></span></div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karlramos/Documents/Codex/2026-10-28/program-outcome-s-po-addressed-by/outputs/purple-pos/resources/views/users/index.blade.php ENDPATH**/ ?>