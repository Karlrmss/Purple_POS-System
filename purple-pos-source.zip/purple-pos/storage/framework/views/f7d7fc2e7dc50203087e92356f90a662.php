<?php $__env->startSection('title', 'Overview'); ?>
<?php $__env->startSection('eyebrow', 'PurplePoint POS'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <section class="hero-card">
        <div class="hero-content">
            <span class="hero-badge">DATABASE-POWERED POS</span>
            <h2>Manage your records.</h2>
            <p>View customers and system users stored in your Laravel database.</p>
            <div class="hero-actions">
                <a class="button button-light" href="<?php echo e(route('customers.index')); ?>">View customers <span>→</span></a>
                <a class="button button-ghost" href="<?php echo e(route('users.index')); ?>">Manage users</a>
            </div>
        </div>
    </section>

    <section class="stat-grid" aria-label="Database summary">
        <article class="stat-card">
            <div class="stat-icon lavender">
                <svg viewBox="0 0 24 24" fill="none"><path d="M16 20v-1.7A4.3 4.3 0 0 0 11.7 14H7.3A4.3 4.3 0 0 0 3 18.3V20M9.5 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
            </div>
            <div><p>Total customers</p><strong><?php echo e($customerCount); ?></strong></div>
            <a href="<?php echo e(route('customers.index')); ?>" aria-label="Open customers">↗</a>
        </article>
        <article class="stat-card">
            <div class="stat-icon plum">
                <svg viewBox="0 0 24 24" fill="none"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
            </div>
            <div><p>System users</p><strong><?php echo e($userCount); ?></strong></div>
            <a href="<?php echo e(route('users.index')); ?>" aria-label="Open users">↗</a>
        </article>
        <article class="stat-card">
            <div class="stat-icon mint">
                <svg viewBox="0 0 24 24" fill="none"><path d="m4 12 5 5L20 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
            <div><p>Database status</p><strong class="status-text">Healthy</strong></div>
            <span class="pulse"></span>
        </article>
    </section>

    <section class="panel recent-panel">
        <div class="panel-heading">
            <div><p class="eyebrow">Latest entries</p><h3>Recent customers</h3></div>
            <a class="text-link" href="<?php echo e(route('customers.index')); ?>">See all customers <span>→</span></a>
        </div>
        <div class="recent-list">
            <?php $__empty_1 = true; $__currentLoopData = $latestCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="recent-row">
                    <div class="avatar avatar-customer"><?php echo e(collect(explode(' ', $customer->full_name))->map(fn ($name) => $name[0])->take(2)->join('')); ?></div>
                    <div class="recent-name"><strong><?php echo e($customer->full_name); ?></strong><small><?php echo e($customer->email); ?></small></div>
                    <span class="phone"><?php echo e($customer->phone); ?></span>
                    <span class="record-pill">Customer</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state">No customers found. Run the database seeder to add sample records.</div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karlramos/Documents/Codex/2026-10-28/program-outcome-s-po-addressed-by/outputs/purple-pos/resources/views/dashboard.blade.php ENDPATH**/ ?>