<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    use RefreshDatabase;

    public function test_dashboard_displays_database_totals(): void
    {
        Customer::create([
            'full_name' => 'Mikaela Santos',
            'email' => 'mikaela@example.com',
            'phone' => '+63 917 000 0000',
        ]);
        User::create(['username' => 'karl.admin', 'full_name' => 'Karl Ramos']);

        $response = $this->get('/');

        $response->assertOk()
            ->assertSee('Manage your records')
            ->assertSee('Recent customers')
            ->assertSee('Mikaela Santos');
    }

    public function test_customer_page_reads_and_filters_eloquent_records(): void
    {
        Customer::create([
            'full_name' => 'Angela Cruz',
            'email' => 'angela@example.com',
            'phone' => '+63 905 774 2091',
        ]);
        Customer::create([
            'full_name' => 'Paolo Reyes',
            'email' => 'paolo@example.com',
            'phone' => '+63 998 510 3487',
        ]);

        $response = $this->get('/customers?search=Angela');

        $response->assertOk()
            ->assertSee('Angela Cruz')
            ->assertDontSee('Paolo Reyes');
    }

    public function test_user_page_reads_and_filters_eloquent_records(): void
    {
        User::create(['username' => 'ria.manager', 'full_name' => 'Maria Isabel Torres']);
        User::create(['username' => 'sam.inventory', 'full_name' => 'Samuel Dela Cruz']);

        $response = $this->get('/users?search=ria.manager');

        $response->assertOk()
            ->assertSee('Maria Isabel Torres')
            ->assertSee('ria.manager')
            ->assertDontSee('Samuel Dela Cruz');
    }
}
